# ColorTextEditorDemo
Demo project for https://github.com/BalazsJako/ImGuiColorTextEdit
